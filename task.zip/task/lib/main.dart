import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'add.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'task',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'List'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, @required this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.search),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: [
                RaisedButton(
                  onPressed: () {},
                  child: Text('ASC'),
                ),
                SizedBox(
                  width: 100.0,
                  height: 0.0,
                ),
                RaisedButton(
                  onPressed: () {},
                  child: Text('Des'),
                ),
                SizedBox(
                  height: 10.0,
                ),
              ],
            ),
            SizedBox(
              height: 20.0,
            ),
            Container(
              child: Card(
                elevation: 2.0,
                child: InkWell(
                  child: Padding(
                    padding: EdgeInsets.all(11.0),
                    child: Column(
                      children: [
                        ListTile(
                          title: Text('Product Name'),
                          subtitle: Text(
                              'Product Description Product Description Product Description Product Description'),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        ListTile(
                          title: Text('Product Name'),
                          subtitle: Text(
                              'Product Description Product Description Product Description Product Description'),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        ListTile(
                          title: Text('Product Name'),
                          subtitle: Text(
                              'Product Description Product Description Product Description Product Description'),
                        ),
                        ListTile(
                          title: Text('Product Name'),
                          subtitle: Text(
                              'Product Description Product Description Product Description Product Description'),
                        ),
                        ListTile(
                          title: Text('Product Name'),
                          subtitle: Text(
                              'Product Description Product Description Product Description Product Description'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => AddScreen()));
        },
        child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}

getdata() async {
  var data = await Firestore.instance
      .collection('production')
      .document('jGlH8dp0cUfp63GsaPgN')
      .snapshots();
  print(data);
}
