import 'package:flutter/material.dart';

class AddScreen extends StatefulWidget {
  @override
  _AddScreenState createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  final TextEditingController _nameEditingController =
      new TextEditingController();

  final TextEditingController _descEditingController =
      new TextEditingController();

  @override
  void dispose() {
    super.dispose();
    _nameEditingController.dispose();
    _descEditingController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add'),
      ),
      body: Container(
        padding: EdgeInsets.all(18.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(labelText: 'Product Name'),
              controller: _nameEditingController,
            ),
            SizedBox(
              height: 20.0,
            ),
            TextField(
              decoration: InputDecoration(labelText: 'description'),
              controller: _descEditingController,
              maxLines: 5,
            ),
            SizedBox(
              height: 20.0,
            ),
            RaisedButton(
              onPressed: () {},
              child: Text('ADD'),
            )
          ],
        ),
      ),
    );
  }
}

// _getdetails() async {
//   final uid = await Provider.of(context).auth.getCurrentUID();
//   var snapshot = await Firestore.instance
//       .collection('data')
//       .where("field", fun)
//       .orderBy('field')
//       .limit(1)
//       .getDocuments();
//   return task.fromSnapshot(snapshot.documents.first);
//}
