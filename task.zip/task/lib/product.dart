import 'package:firebase_database/firebase_database.dart';

class prod {
  final String name;
  final String desc;

  prod({
    this.name,
    this.desc,
  });

  prod.fromSnapshot(DataSnapshot snapshot) :
        name = snapshot.valuse["name"],
        imageUrl = snapshot.value["imageUrl"],
    
  toJson() {
    return {
      "caption": caption,
      "title": title,
    };
  }
}